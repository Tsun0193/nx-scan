from .. import model_factory
from .identity import LitIdentity

model_factory.register_model("identity", LitIdentity)
